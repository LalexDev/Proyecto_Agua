﻿import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface SuministroLecturadorResponse {
  id: number;
  codigoSuministro: string;
  nombreSector: string;
  direccionSuministro: string;
  referencia: string;
  aliasSuministro: string;
  lecturaInicial: number;
  estado: boolean;

  estadoInstalacion?: string;
  permiteRegistrarLectura?: boolean;
  permiteGenerarMantenimiento?: boolean;
  mensajeEstado?: string;

  lecturaAnterior?: number;
  anioUltimaLectura?: number | null;
  mesUltimaLectura?: number | null;

  nombreCliente?: string;
  dniCliente?: string;
}

export interface LecturaRequest {
  codigoSuministro: string;
  anio: number;
  mes: number;
  lecturaActual: number;
  observacion: string;

  cambioMedidor?: boolean;
  lecturaInicialNuevoMedidor?: number | null;
  observacionCambioMedidor?: string;
}

export interface MantenimientoRequest {
  codigoSuministro: string;
  anio: number;
  mes: number;
  observacion: string;
}

export interface ReciboGeneradoResponse {
  id: number;
  codigoRecibo: string;
  codigoSuministro?: string;
  direccionSuministro?: string;

  anio: number;
  mes: number;

  consumoM3: number;
  subtotalAgua: number;
  cargoMantenimiento: number;
  cargoLector: number;
  cargoOtros: number;
  mora: number;
  total: number;

  estadoRecibo: string;
  fechaEmision: string;
  fechaVencimiento: string;
  codigoBarras?: string;
}

export interface LecturaResponse {
  id: number;
  codigoSuministro: string;
  direccionSuministro: string;
  anio: number;
  mes: number;
  lecturaAnterior: number;
  lecturaActual: number;
  consumoM3: number;
  fechaLectura: string;
  observacion: string;

  cambioMedidor?: boolean;
  lecturaInicialNuevoMedidor?: number | null;
  observacionCambioMedidor?: string;
  consumoInusual?: boolean;

  recibo: ReciboGeneradoResponse;
}

@Injectable({
  providedIn: 'root',
})
export class Lecturador {
  private readonly apiLecturador = '/api/lecturador';
  private readonly apiLecturas = '/api/lecturas';

  constructor(private http: HttpClient) {}

  buscarSuministro(codigoSuministro: string): Observable<SuministroLecturadorResponse> {
    return this.http.get<SuministroLecturadorResponse>(
      `${this.apiLecturador}/suministros/${codigoSuministro}`
    );
  }

  registrarLectura(data: LecturaRequest): Observable<LecturaResponse> {
    return this.http.post<LecturaResponse>(this.apiLecturas, data);
  }

  registrarMantenimiento(data: MantenimientoRequest): Observable<LecturaResponse> {
    return this.http.post<LecturaResponse>(`${this.apiLecturas}/mantenimiento`, data);
  }
}
